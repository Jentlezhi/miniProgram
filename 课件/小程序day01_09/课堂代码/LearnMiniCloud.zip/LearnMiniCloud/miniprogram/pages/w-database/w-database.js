// miniprogram/pages/w-database/w-database.js
// 1.获取数据库对象
const db = wx.cloud.database();

// 2.获取操作的集合
const collection = db.collection("students");

Page({
  addDataToDB: function() {
    // 向集合中添加一条数据
    collection.add({
      data: {
        name: "tom",
        age: 28,
        height: 1.88,
        courses: ["现在经济", "统计学", "现代文学"],
        goodFriend: {
          name: "hanmeimei",
          age: 20
        },
        location: db.Geo.Point(100, 50),
        birth: new Date("1995-01-01")
      }
    }).then(res => {
      console.log(res)
    }).catch(err => {
      console.log(err)
    })
  },

  removeDataToDB: function() {
    // 精准删除
    // collection
    //   .doc("7c47f3615dd7e45e022b57387fba9e85") // 精准拿到某一个学生
    //   .remove()
    //   .then(res => {
    //     console.log(res)
    //   }).catch(err => {
    //     console.log(err)
    //   })

    // collection.where({
    //   age: 30
    // }).remove().then(res => {
    //   console.log(res)
    // }).catch(err => {
    //   console.log(err)
    // })
  },

  updateDataToDB: function() {
    // update方法: 修改/添加某些字段
    // collection
    //   .doc("fe42f4e05dd7e29d022c08f70764e0dd")
    //   .update({
    //     data: {
    //       age: 30,
    //       score: 100
    //     }
    //   })
    //   .then(console.log)
    //   .catch(console.error)

    // set方法：直接替换对象
    // collection
    //   .doc("fe42f4e05dd7e29d022c08f70764e0dd")
    //   .set({
    //     data: {
    //       age: 30,
    //       score: 100
    //     }
    //   })
    //   .then(console.log)
    //   .catch(console.error)

    collection
      .where({
        name: "why"
      })
      .set({
        data: {
          age: 30,
          score: 100
        }
      })
      .then(console.log)
      .catch(console.error)
  }
})